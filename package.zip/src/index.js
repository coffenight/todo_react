import ReactDOM from 'react-dom';

//* Импорт компонентов
import App from './components/App';


//* Передаем компоненты на отрисовку в заданный элемент
ReactDOM.render(<App />, document.getElementById('root'));
